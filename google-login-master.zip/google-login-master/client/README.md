📦client
 ┣ 📂public
 ┣ 📂src
 ┃ ┣ 📂Context
 ┃ ┃ ┗ 📜AuthContext.tsx
 ┃ ┣ 📂components
 ┃ ┃ ┣ 📜GoogleAuth.tsx
 ┃ ┣ 📂pages
 ┃ ┃  ┗ 📜index.tsx
 ┃ ┃  ┗ 📜index.tsx
 ┃ ┣ 📜App.tsx
 ┃ ┣ 📜index.css
 ┃ ┣ 📜index.tsx
 ┣ 📜.env
 ┣ 📜package.json
 ┣ 📜tailwind.config.js
 ┣ 📜tsconfig.json