/// <reference types="react-scripts" />

// declare module 'reactjs-social-login'
