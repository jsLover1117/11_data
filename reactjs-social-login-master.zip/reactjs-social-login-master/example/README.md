This example was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

It is linked to the reactjs-social-login package in the parent directory for development purposes.

You can run `yarn install` and then `yarn start` to test your package.
